package com.cytech.collections_Fichiers;
import ingredients.Boisson;
import ingredients.Cocktail;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.SerializationFeature;
import java.io.File;
import java.util.ArrayList;

import com.cytech.collections_Fichiers.CollectionIngredient;

import com.fasterxml.jackson.databind.ObjectMapper;
import ingredients.Produit;

public class CollectionCocktail {
    private static ArrayList<Cocktail> cocktails;
    private static final String cocktailsJson = "src/main/resources/cocktails.json";
    private static ObjectMapper objectMapper;

    public CollectionCocktail() {
        objectMapper = new ObjectMapper();
        objectMapper.enable(SerializationFeature.INDENT_OUTPUT);//met bien le fichier en ordre
        try {
            JsonNode jsonNode = objectMapper.readTree(new File(cocktailsJson));
            cocktails = objectMapper.readValue(jsonNode.toString(), objectMapper.getTypeFactory().constructCollectionType(ArrayList.class, Cocktail.class));
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public static boolean chercherCocktails(String name) {
        for (Cocktail cocktail : cocktails) {
            if (cocktail.getName().equals(name) && cocktail.getStock() > 0) {
                return true;
            }
        }
        return false;
    }

    public void saveCocktail(Cocktail cocktail) {
        // append the cocktail to the cocktails.json file
        try {
            if (cocktails.contains(cocktail)) {
                System.err.println("Cocktail " + cocktail.getName() + " already exists");
            }
            cocktails.add(cocktail);
            objectMapper.writeValue(new File(cocktailsJson), cocktails);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void deleteCocktail(String name) {
        Cocktail cocktail = cocktails.stream().filter(c -> c.getName().equals(name)).findFirst().orElse(null);
        // remove the cocktail from the cocktails.json file
        try {
            cocktails.remove(cocktail);
            objectMapper.writeValue(new File(cocktailsJson), cocktails);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void consumeCocktail(String name) {
        try {

            for (Cocktail cocktail : cocktails) {
                if (cocktail.getName().equals(name)) {
                    cocktail.setStock(cocktail.getStock() - cocktail.getQuantity());
                    break;
                }

                objectMapper.writeValue(new File(cocktailsJson), cocktails);
            }
        }
        catch(Exception e){

            e.printStackTrace();
        }

    }
}
