package ingredients;

import java.util.ArrayList;

public class Cocktail extends Produit{
    private float alcohol;
    private float sugar;
    private ArrayList<Produit> produits;





    public Cocktail ( String name,Produit[] args ) {
        super(name, 0, 0);
        calculerPrice ();
        for( Produit prod : args)

            produits = new ArrayList<Produit>();
        for( Produit prod: args) {
            produits.add(prod);
        }
    }

    public void setSugar() {
        for( Produit prod: produits) {
            if (prod instanceof Boisson) {
                this.sugar=this.sugar+((Boisson) prod).getSugar();

            } else {
                this.sugar=this.sugar+0;

            }
        }
    }


    public float getSugar(){
        return this.sugar;
    }


    public void setAlcohol() {
        for( Produit prod: produits) {
            if (prod instanceof Boisson) {
                this.alcohol+=((Boisson) prod).getAlcohol();

            } else {
                this.alcohol=this.alcohol+0;

            }
        }
    }


    public float getAlcohol() {
        return this.alcohol;
    }

    public void calculerPrice () {
        float price = 0;
        for( Produit prod: produits) {
            price+= prod.getPrice();
        }
        price+=0.1*price;
        setPrice(price);
    }


}
