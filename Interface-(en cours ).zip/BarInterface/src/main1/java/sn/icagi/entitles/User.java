package sn.icagi.entitles;

public class User {

    private int id;

    private String adresseMail;

    private Client client ;
    private Barman barman;
    private String password;

    public User (String nom , Barman barman , Client client , String password , String adresseMail){

        this.adresseMail = adresseMail;
        this.barman = barman;
        this.password = password ;
        this.client= client;
        this.barman=barman;


    }


}
