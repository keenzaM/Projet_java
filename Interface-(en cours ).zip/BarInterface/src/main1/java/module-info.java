module com.example.barinterface {
    requires javafx.controls;
    requires javafx.fxml;

    requires com.dlsc.formsfx;
    requires org.jetbrains.annotations;

    opens main to javafx.fxml;
    exports main;


}