package ingredients;

public class Barman {

    private String nom;


    public Barman(String nom) {
        this.nom = nom ;

    }


}
