package sn.icagi.entitles;

public class Ingredient extends Produit {
    public Ingredient ( String nom ,float prix, float stock  ){
        super(nom, prix , stock);

    }
}
