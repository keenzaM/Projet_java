package tools;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class MostUse {
    public void loadPage(ActionEvent event , String title , String url) throws IOException {
        ((Node) event.getSource()).getScene().getWindow().hide();
        Parent root = FXMLLoader.load((getClass().getResource(url)));
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.show();

    }
    public static void load(ActionEvent event , String title , String url ) throws IOException {
        new MostUse().loadPage(event, title , url);
    }
    public static boolean estBarman(String nomUtilisateur) {
        if (nomUtilisateur == null || nomUtilisateur.isEmpty()) {
            return false;
        }
        if (nomUtilisateur.toLowerCase().startsWith("barman")) {

            return true;
        } else {
            return false;
        }
    }

    public static boolean estClient(String nomUtilisateur) {

        if (nomUtilisateur == null || nomUtilisateur.isEmpty()) {
            return false;
        }

        if (nomUtilisateur.toLowerCase().startsWith("client")) {

            return true;
        } else {
            return false;
        }
    }


}
