package com.cytech.collections_Fichiers;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import ingredients.Boisson;


import java.io.File;
import java.util.ArrayList;


public class CollectionBoisson {
    private static ArrayList<Boisson> boissons;

    private static final String boissonsJson = "src/main/resources/boissons.json";
    private static ObjectMapper objectMapper;

    public CollectionBoisson() {
        objectMapper = new ObjectMapper();
        objectMapper.enable(SerializationFeature.INDENT_OUTPUT);//met bien le fichier en ordre
        try {
            JsonNode jsonNode = objectMapper.readTree(new File(boissonsJson));
            boissons = objectMapper.readValue(jsonNode.toString(), objectMapper.getTypeFactory().constructCollectionType(ArrayList.class, Boisson.class));
        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    public static boolean chercherBoissons(String name) {
        for (Boisson boisson : boissons) {
            if (boisson.getName().equals(name) && boisson.getStock() > 0) {
                return true;
            }
        }
        return false;
    }

    public static void consumeBoisson(String name) {
        try {

            for (Boisson boisson : boissons) {
                if (boisson.getName().equals(name)) {
                    boisson.setStock(boisson.getStock() - boisson.getQuantity());
                    break;
                }
            }
            objectMapper.writeValue(new File(boissonsJson), boissons);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }
}