package ingredients;

public class Produit {
    private String name ;// Attribut privé de type String
    private float stock ;
    private float quantity ;


    private float price ;

    public Produit( String name , float price , float stock){
        this.name = name;
        this.price = price;
        this.stock = stock;

    }

    public void setNom(String nom) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
    public void setPrice( float price ){
        this.price=price;
    }

    public float getPrice() {
        return this.price;
    }


    public void setStock(float stock) {
        this.stock=stock;
    }

    public float getStock() {
        return this.stock;
    }

    public void setQuantity(float quantity) {
        this.quantity=quantity;
    }

    public float getQuantity() {
        return this.quantity;
    }

}
