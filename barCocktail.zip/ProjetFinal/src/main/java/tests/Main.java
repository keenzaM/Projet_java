package tests;

import ingredients.Boisson;

public class Main {
    public static void main(String[] args){
        Boisson coca = new Boisson("coca", 1, 100,  0, 0.4f);
        System.out.println("Boisson : " +coca.getName() + " Prix" +coca.getPrice()+ " Stock " +coca.getStock()+ " Degre d'alcool "+coca.getAlcohol()+" degreSucre "+coca.getSugar());

    }
}
