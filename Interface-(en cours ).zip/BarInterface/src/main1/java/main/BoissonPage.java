package main;

public class BoissonPage {
}
