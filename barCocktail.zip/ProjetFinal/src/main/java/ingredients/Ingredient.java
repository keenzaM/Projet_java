package ingredients;

public class Ingredient extends Produit{
    public Ingredient ( String nom ,float prix, int stock  ){
        super(nom, prix , stock);

    }
}
