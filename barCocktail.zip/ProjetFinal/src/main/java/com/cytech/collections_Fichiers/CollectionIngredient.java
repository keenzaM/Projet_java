package com.cytech.collections_Fichiers;
import com.fasterxml.jackson.databind.ObjectMapper;
import ingredients.Boisson;
import ingredients.Cocktail;
import ingredients.Ingredient;
import ingredients.Produit;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.SerializationFeature;
import java.io.File;
import java.util.ArrayList;



public class CollectionIngredient {
    private static ArrayList<Ingredient> ingredients;
    private static final String ingredientJson = "src/main/resources/ingredients.json";
    private static ObjectMapper objectMapper;

    public CollectionIngredient(){
        objectMapper = new ObjectMapper();
        objectMapper.enable(SerializationFeature.INDENT_OUTPUT);//met bien le fichier en ordre

        try {
            JsonNode jsonNode = objectMapper.readTree(new File(ingredientJson));
            ingredients = objectMapper.readValue(jsonNode.toString(), objectMapper.getTypeFactory().constructCollectionType(ArrayList.class, Ingredient.class));

        }
        catch (Exception e) {
            e.printStackTrace();
        }

    }

    public static boolean chercherIngredients(String name) {
        for (Ingredient ingredient : ingredients) {
            if (ingredient.getName().equals(name) && ingredient.getStock() > 0) {
                return true;
            }
        }
        return false;
    }
    public static void consumeIngredient(String name)  {
        try {
            for(Ingredient ingredient : ingredients){
                if( ingredient.getName().equals(name)) {
                    ingredient.setStock(ingredient.getStock() - ingredient.getQuantity());
                    break;
                }
            }
            objectMapper.writeValue(new File(ingredientJson), ingredients);
        }catch (Exception e){

            e.printStackTrace();
        }
    }

}
