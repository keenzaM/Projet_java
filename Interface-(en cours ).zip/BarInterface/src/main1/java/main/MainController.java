package main;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import tools.MostUse;

import java.io.IOException;

public class MainController {
    @FXML
    private TextField userNameL ;
    @FXML
    private PasswordField passworldL;

    public void getLogin(ActionEvent event){

        String userName = userNameL.getText();
        String passworld = passworldL.getText();
        if (userName.equals(userName)){
            Main.afficherAutrepage();
        }
        else{
            System.out.println("Le nom n'est pas 'barman'.");
        }

    }


}