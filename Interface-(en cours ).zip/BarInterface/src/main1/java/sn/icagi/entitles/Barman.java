package sn.icagi.entitles;

public class Barman extends Client {
    private String nom;


    public Barman(String nom, String prenom, String adresseMail, String dateNaissance, String phraseSecrete) {
        super(nom, prenom, adresseMail, dateNaissance, phraseSecrete);
    }
}
