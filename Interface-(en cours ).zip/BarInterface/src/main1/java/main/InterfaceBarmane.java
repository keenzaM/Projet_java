package main;

import javafx.fxml.Initializable;

import java.net.URL;
import java.util.ResourceBundle;

public class InterfaceBarmane implements Initializable {

    public void loadBoisson (){
        try {
            Main.afficherBoissons();

        }
        catch (Exception ex){
        }

    }
    public void loadIngredients() {
        try {
            Main.afficherIngredients();

        }
        catch (Exception ex){
        }
    }

    public void loadCocktails(){

    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }
}
