package main;


import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import sn.icagi.entitles.Ingredient;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class IngredientsInterface implements Initializable {
    @FXML
    private Button gererStock ;
    @FXML
    private TableView<Ingredient> tableIngredients ;
    @FXML
    private TableColumn<Ingredient, String> idNom;
    @FXML
    private TableColumn<Ingredient, Float > idStock ;

    public void GererStock(){

    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        idNom.setCellValueFactory(new PropertyValueFactory<>("name"));
        idStock.setCellValueFactory(new PropertyValueFactory<>("stock"));
        load();

    }

    public void load (){
        ObservableList<Ingredient> obIngredients = FXCollections.observableArrayList();
        ArrayList<Ingredient> listeIngredients = Main.listeIngredients();
        for (Ingredient i : listeIngredients ){
            obIngredients.add(i);
        }
        tableIngredients.setItems(obIngredients);
    }
}
