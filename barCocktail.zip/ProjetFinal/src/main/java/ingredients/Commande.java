package ingredients;
import com.cytech.collections_Fichiers.CollectionBoisson;
import com.cytech.collections_Fichiers.CollectionBarman;
import com.cytech.collections_Fichiers.CollectionCocktail;
import com.cytech.collections_Fichiers.CollectionIngredient;

import java.io.File;
import java.util.ArrayList;

import static com.cytech.collections_Fichiers.CollectionCocktail.consumeCocktail;
//import static com.sun.tools.classfile.AccessFlags.Kind.Method;

public class Commande {
    private Barman barmanC ;
    private Client clientC ;

    private ArrayList<Produit> produitsBrut ;
    private ArrayList<Produit> coktailPersonnalisé;
    private float bill ; /*montantpayé*/
    private static float turnover; /*chiffred'affaire*/
    boolean produitsDisponibles = true;




    public Commande ( Barman barmanc , Client clientc , Produit[] produitsBrut  , Produit[] coktailPersonnalise)
    {
        this.barmanC=barmanc;
        this.clientC= clientc;
        for( Produit prodBrut : produitsBrut ){
            if ( prodBrut instanceof Boisson ) {
                if( CollectionBoisson.chercherBoissons(prodBrut.getName())){
                    this.produitsBrut.add(prodBrut);
                    CollectionBoisson.consumeBoisson(prodBrut.getName());
                    this.bill+=prodBrut.getPrice();


                }
                else{

                    produitsDisponibles = false; // Le produit n'est pas disponible
                    System.out.println("le produit n'est pas disponible");
                    break; // Sortir de la boucle car un produit n'est pas disponible
                }
            }
            else if (prodBrut instanceof Ingredient) {
                if(CollectionIngredient.chercherIngredients(prodBrut.getName())){
                    this.produitsBrut.add(prodBrut);
                    CollectionIngredient.consumeIngredient(prodBrut.getName());
                    this.bill+=prodBrut.getPrice();

                }
                else{
                    produitsDisponibles = false; // Le produit n'est pas disponible
                    System.out.println("le produit n'est pas disponible");
                    break; // Sortir de la boucle car un produit n'est pas disponible
                }
            }
            else if (prodBrut instanceof Cocktail){
                if( CollectionCocktail.chercherCocktails(prodBrut.getName())){
                    this.produitsBrut.add(prodBrut);
                    consumeCocktail(prodBrut.getName());
                    this.bill+=prodBrut.getPrice();

                }
                else{
                    produitsDisponibles = false; // Le produit n'est pas disponible
                    System.out.println("le produit n'est pas disponible");
                    break; // Sortir de la boucle car un produit n'est pas disponible
                }

            }

        }
        for ( Produit ingredPreso : coktailPersonnalise) {
            if (ingredPreso instanceof Boisson) {
                if (CollectionBoisson.chercherBoissons(ingredPreso.getName())) {
                    this.produitsBrut.add(ingredPreso);
                    CollectionBoisson.consumeBoisson(ingredPreso.getName());
                    this.bill += ingredPreso.getPrice() + 0.1 * ingredPreso.getPrice();
                } else {
                    produitsDisponibles = false; // Le produit n'est pas disponible
                    System.out.println("le produit n'est pas disponible");
                    break; // Sortir de la boucle car un produit n'est pas disponible
                }
            }
            else if (ingredPreso instanceof Ingredient) {
            if( CollectionIngredient.chercherIngredients(ingredPreso.getName())){
                this.produitsBrut.add(ingredPreso);
                CollectionIngredient.consumeIngredient(ingredPreso.getName());
                this.bill+=ingredPreso.getPrice()+ingredPreso.getPrice();

            }
            else{
                produitsDisponibles = false; // Le produit n'est pas disponible
                System.out.println("le produit n'est pas disponible");
                break; // Sortir de la boucle car un produit n'est pas disponible
            }


        }
        else if (ingredPreso instanceof Cocktail){
            if( CollectionCocktail.chercherCocktails(ingredPreso.getName())){
                this.produitsBrut.add(ingredPreso);
                CollectionIngredient.consumeIngredient(ingredPreso.getName());
                this.bill+=ingredPreso.getPrice()+0.1*ingredPreso.getPrice();

            }
            else{
                produitsDisponibles = false; // Le produit n'est pas disponible
                System.out.println("le produit n'est pas disponible");
                break; // Sortir de la boucle car un produit n'est pas disponible
            }

        }


        }
        if (produitsDisponibles) {
            turnover += this.bill;
        }

    }
    public float getTurnover(){
        return this.turnover;
    }
}
