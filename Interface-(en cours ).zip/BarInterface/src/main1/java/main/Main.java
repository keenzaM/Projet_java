package main;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import sn.icagi.entitles.Boisson;
import sn.icagi.entitles.Ingredient;
import sn.icagi.entitles.Produit;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Objects;

import static javafx.application.Application.launch;

public class Main extends Application {
    public static ArrayList listeIngredients(){
        ArrayList listeIngredients = new ArrayList();
        try {
            Ingredient menthe = new Ingredient("menthe", 0.1F, 14f);
            Ingredient citron = new Ingredient("citron", 0.9F, 20f);

            listeIngredients.add(menthe);
            listeIngredients.add(citron);

        }
        catch(Exception ex){
            ex.printStackTrace();
        }
        return listeIngredients;
    }





    @Override
    public void start( Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("main.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 400, 300);
        stage.setTitle("Connexion");
        stage.setScene(scene);
        stage.show();
    }

    public static void afficherAutrepage() {
        try {
            Parent root = FXMLLoader.load(Main.class.getResource("InterfaceBarmane.fxml"));
            Stage stage = new Stage();
            stage.setTitle("Autre Page");
            stage.setScene(new Scene(root, 300, 275));
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public static void afficherBoissons() {
        try {
            Parent root = FXMLLoader.load(Main.class.getResource("BoissonPage.fxml"));
            Stage stage = new Stage();
            stage.setTitle("Autre Page");
            stage.setScene(new Scene(root, 300, 275));
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void afficherIngredients() {
        try {
            Parent root = FXMLLoader.load(Main.class.getResource("IngredientsInterface.fxml"));
            Stage stage = new Stage();
            stage.setTitle("Autre Page");
            stage.setScene(new Scene(root, 300, 275));
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public static void main(String[] args) {
        launch();
    }
}